package gradle;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

class PesadoTest {

    @Test
    void testConstrutor() {
        // Cria data
        Date data = new Date();
        // Instancia Pesado
        Pesado pesado = new Pesado(1, "PesadoTest", 10, 5, 8, data);
        // Verifica id
        assertEquals(1, pesado.getId());
        // Verifica codinome
        assertEquals("PesadoTest", pesado.getCodinome());
        // Verifica blindagem
        assertEquals(10, pesado.getBlindagem());
        // Verifica velocidade
        assertEquals(5, pesado.getVelocidade());
        // Verifica poderDeFogo
        assertEquals(8, pesado.getPoderDeFogo());
        // Verifica vida
        assertEquals(100, pesado.getVida());
        // Verifica horaEntradaArena
        assertEquals(data, pesado.getHoraEntradaArena());
    }

    @Test
    void testCaracterisrticas() {
        // Instancia Pesado
        Pesado pesado = new Pesado(1, "PesadoTest", 10, 5, 8, new Date());
        // Chama método
        pesado.Caracterisrticas();
        // Verifica blindagem aumentada
        assertEquals(20, pesado.getBlindagem());
        // Verifica velocidade aumentada
        assertEquals(3, pesado.getVelocidade());
        // Verifica poderDeFogo aumentado
        assertEquals(13, pesado.getPoderDeFogo());
    }

    @Test
    void testToString() {
        // Instancia Pesado
        Pesado pesado = new Pesado(1, "PesadoTest", 10, 5, 8, new Date());
        // Obtém toString
        String str = pesado.toString();
        // Verifica se contém codinome
        assertTrue(str.contains("PesadoTest"));
    }
}
