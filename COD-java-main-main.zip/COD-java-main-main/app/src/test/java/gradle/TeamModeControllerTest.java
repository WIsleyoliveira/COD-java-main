package gradle;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TeamModeControllerTest {

    private TeamModeController controller;

    @BeforeEach
    void setUp() {
        controller = new TeamModeController();
    }

    @Test
    void testInstantiation() {
        assertNotNull(controller);
    }

    @Test
    void testCreateBotTank() {
        // Testa criação de bot usando reflexão
        try {
            java.lang.reflect.Method method = TeamModeController.class.getDeclaredMethod("createBotTank");
            method.setAccessible(true);
            Tanque bot = (Tanque) method.invoke(controller);
            assertNotNull(bot);
            assertNotNull(bot.getCodinome());
        } catch (Exception e) {
            fail("Erro ao testar criação de bot: " + e.getMessage());
        }
    }
}
