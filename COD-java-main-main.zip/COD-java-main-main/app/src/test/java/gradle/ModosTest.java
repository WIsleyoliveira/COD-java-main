package gradle;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.Date;

class ModosTest {

    private Modos modos;
    private ArrayList<Tanque> tanquesAliado;
    private ArrayList<Tanque> tanqueInimigo;

    @BeforeEach
    void setUp() {
        tanquesAliado = new ArrayList<>();
        tanqueInimigo = new ArrayList<>();
        modos = new Modos(new Date(), 2.0, 1, tanquesAliado, tanqueInimigo);
    }

    @Test
    void testConstrutor() {
        assertNotNull(modos);
        assertEquals(tanquesAliado, modos.tanquesAliado);
        assertEquals(tanqueInimigo, modos.tanqueInimigo);
    }

    @Test
    void testListarPartidasVazia() {
        // Testa listarPartidas quando não há partidas agendadas
        // Como o método imprime na tela, apenas verificamos se não lança exceção
        assertDoesNotThrow(() -> modos.listarPartidas());
    }

    @Test
    void testListarPartidasComPartidas() {
        // Adiciona uma partida manualmente
        modos.partidasAgendadas.add("Teste - Arena - 01/01/2024 12:00:00");

        // Testa listarPartidas quando há partidas agendadas
        assertDoesNotThrow(() -> modos.listarPartidas());
        assertEquals(1, modos.partidasAgendadas.size());
    }

    @Test
    void testModoTreinoSemTanques() {
        // Testa modoTreino sem tanques - deve imprimir mensagem e retornar
        assertDoesNotThrow(() -> modos.modoTreino());
    }

    @Test
    void testModoPvPSemTanques() {
        // Testa modoPvP sem tanques
        assertDoesNotThrow(() -> modos.modoPvP());
    }
}
