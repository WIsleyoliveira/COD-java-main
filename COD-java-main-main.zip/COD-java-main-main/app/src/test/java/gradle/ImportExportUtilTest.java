package gradle;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class ImportExportUtilTest {

    @Test
    void testExportToJSON() throws IOException {
        // Cria listas de tanques
        List<Tanque> alliedTeam = new ArrayList<>();
        alliedTeam.add(new Leve(1, "Leve1", 10, 5, 8, new Date()));
        List<Tanque> enemyTeam = new ArrayList<>();
        enemyTeam.add(new Pesado(2, "Pesado1", 15, 3, 10, new Date()));

        // Define caminho do arquivo
        String filePath = "test_export.json";

        // Chama método
        ImportExportUtil.exportToJSON(alliedTeam, enemyTeam, filePath);

        // Verifica se arquivo foi criado (simplesmente não lança exceção)
        assertTrue(true);
    }

    @Test
    void testImportFromJSON() throws IOException {
        // Cria listas de tanques
        List<Tanque> alliedTeam = new ArrayList<>();
        alliedTeam.add(new Leve(1, "Leve1", 10, 5, 8, new Date()));
        List<Tanque> enemyTeam = new ArrayList<>();
        enemyTeam.add(new Pesado(2, "Pesado1", 15, 3, 10, new Date()));

        // Define caminho do arquivo
        String filePath = "test_import.json";

        // Exporta primeiro
        ImportExportUtil.exportToJSON(alliedTeam, enemyTeam, filePath);

        // Importa
        ImportExportUtil.TeamData data = ImportExportUtil.importFromJSON(filePath);

        // Verifica
        assertEquals(1, data.alliedTeam.size());
        assertEquals(1, data.enemyTeam.size());
        assertEquals("Leve1", data.alliedTeam.get(0).getCodinome());
        assertEquals("Pesado1", data.enemyTeam.get(0).getCodinome());
    }
}
