package gradle;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

class LeveTest {

    @Test
    void testConstrutor() {
        // Cria data
        Date data = new Date();
        // Instancia Leve
        Leve leve = new Leve(1, "LeveTest", 10, 5, 8, data);
        // Verifica id
        assertEquals(1, leve.getId());
        // Verifica codinome
        assertEquals("LeveTest", leve.getCodinome());
        // Verifica blindagem
        assertEquals(10, leve.getBlindagem());
        // Verifica velocidade
        assertEquals(5, leve.getVelocidade());
        // Verifica poderDeFogo
        assertEquals(8, leve.getPoderDeFogo());
        // Verifica vida
        assertEquals(100, leve.getVida());
        // Verifica horaEntradaArena
        assertEquals(data, leve.getHoraEntradaArena());
    }

    @Test
    void testCaracterisrticas() {
        // Instancia Leve
        Leve leve = new Leve(1, "LeveTest", 10, 5, 8, new Date());
        // Chama método
        leve.Caracterisrticas();
        // Verifica blindagem aumentada
        assertEquals(15, leve.getBlindagem());
        // Verifica velocidade aumentada
        assertEquals(10, leve.getVelocidade());
        // Verifica poderDeFogo aumentado
        assertEquals(13, leve.getPoderDeFogo());
    }

    @Test
    void testToString() {
        // Instancia Leve
        Leve leve = new Leve(1, "LeveTest", 10, 5, 8, new Date());
        // Obtém toString
        String str = leve.toString();
        // Verifica se contém codinome
        assertTrue(str.contains("LeveTest"));
    }
}
