package gradle;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class ManualBattleControllerTest {

    private ManualBattleController controller;
    private List<Tanque> alliedTeam;
    private List<Tanque> enemyTeam;

    @BeforeEach
    void setUp() {
        controller = new ManualBattleController();
        alliedTeam = new ArrayList<>();
        enemyTeam = new ArrayList<>();

        // Criar tanques de teste
        Date data = new Date();
        alliedTeam.add(new Leve(1, "Tank1", 50, 80, 60, data));
        alliedTeam.add(new Medio(2, "Tank2", 70, 60, 75, data, 0, 0, 0.0, null));
        enemyTeam.add(new Pesado(3, "Tank3", 90, 40, 85, data));
    }

    @Test
    void testCalculateDamage() {
        // Testa cálculo de dano entre diferentes tipos de tanque
        Date data = new Date();
        Tanque leve = new Leve(1, "Leve", 50, 80, 60, data);
        Tanque medio = new Medio(2, "Medio", 70, 60, 75, data, 0, 0, 0.0, null);
        Tanque pesado = new Pesado(3, "Pesado", 90, 40, 85, data);

        // Testa vantagens de tipo (usando reflexão para acessar método privado)
        try {
            java.lang.reflect.Method method = ManualBattleController.class.getDeclaredMethod("calculateDamage", Tanque.class, Tanque.class);
            method.setAccessible(true);

            // Leve vs Pesado (vantagem)
            int damage1 = (int) method.invoke(controller, leve, pesado);
            assertTrue(damage1 > leve.getAtaque()); // Deve ser maior que o ataque base

            // Pesado vs Leve (desvantagem)
            int damage2 = (int) method.invoke(controller, pesado, leve);
            assertTrue(damage2 < pesado.getAtaque()); // Deve ser menor que o ataque base

        } catch (Exception e) {
            fail("Erro ao testar cálculo de dano: " + e.getMessage());
        }
    }

    @Test
    void testCountAliveTanks() {
        // Testa contagem de tanques vivos
        try {
            java.lang.reflect.Method method = ManualBattleController.class.getDeclaredMethod("countAliveTanks", List.class);
            method.setAccessible(true);

            // Todos vivos
            int count1 = (int) method.invoke(controller, alliedTeam);
            assertEquals(2, count1);

            // Mata um tanque
            alliedTeam.get(0).setVida(0);
            int count2 = (int) method.invoke(controller, alliedTeam);
            assertEquals(1, count2);

        } catch (Exception e) {
            fail("Erro ao testar contagem de tanques vivos: " + e.getMessage());
        }
    }

    @Test
    void testInstantiation() {
        // Testa se o controller pode ser instanciado
        assertNotNull(controller);
    }
}
