package gradle;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BotTest {

    @Test
    void testBotInstantiation() {
        // Testa se é possível instanciar a classe Bot
        Bot bot = new Bot();
        assertNotNull(bot);
    }
}
