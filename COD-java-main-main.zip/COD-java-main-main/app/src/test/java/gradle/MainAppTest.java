package gradle;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

class MainAppTest {

    @BeforeEach
    void setUp() {
        // Limpa listas estáticas antes de cada teste
        MainApp.getTanquesAliado().clear();
        MainApp.getTanqueInimigo().clear();
    }

    @Test
    void testGetTanquesAliado() {
        ArrayList<Tanque> tanquesAliado = MainApp.getTanquesAliado();
        assertNotNull(tanquesAliado);
        assertTrue(tanquesAliado.isEmpty());
    }

    @Test
    void testGetTanqueInimigo() {
        ArrayList<Tanque> tanqueInimigo = MainApp.getTanqueInimigo();
        assertNotNull(tanqueInimigo);
        assertTrue(tanqueInimigo.isEmpty());
    }

    @Test
    void testGetNextTankId() {
        int id1 = MainApp.getNextTankId();
        int id2 = MainApp.getNextTankId();

        assertTrue(id1 < id2);
        assertTrue(id1 >= 1000);
        assertTrue(id2 >= 1000);
    }
}
