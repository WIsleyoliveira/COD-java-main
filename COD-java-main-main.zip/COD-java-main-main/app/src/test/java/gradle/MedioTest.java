package gradle;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import java.util.Date;

class MedioTest {

    @Test
    void testConstrutor() {
        // Cria data
        Date data = new Date();
        // Instancia Medio
        Medio medio = new Medio(1, "MedioTest", 10, 5, 8, data, 2, 3, 1.5, Duration.ofSeconds(10));
        // Verifica id
        assertEquals(1, medio.getId());
        // Verifica codinome
        assertEquals("MedioTest", medio.getCodinome());
        // Verifica blindagem
        assertEquals(10, medio.getBlindagem());
        // Verifica velocidade
        assertEquals(5, medio.getVelocidade());
        // Verifica poderDeFogo
        assertEquals(8, medio.getPoderDeFogo());
        // Verifica vida
        assertEquals(100, medio.getVida());
        // Verifica horaEntradaArena
        assertEquals(data, medio.getHoraEntradaArena());
    }

    @Test
    void testCaracterisrticas() {
        // Instancia Medio
        Medio medio = new Medio(1, "MedioTest", 10, 5, 8, new Date(), 2, 3, 1.5, Duration.ofSeconds(10));
        // Chama método
        medio.Caracterisrticas();
        // Verifica danoBase
        assertEquals(15, medio.danoBase);
    }

    @Test
    void testToString() {
        // Instancia Medio
        Medio medio = new Medio(1, "MedioTest", 10, 5, 8, new Date(), 2, 3, 1.5, Duration.ofSeconds(10));
        // Obtém toString
        String str = medio.toString();
        // Verifica se contém codinome
        assertTrue(str.contains("MedioTest"));
    }
}
