// Declara o pacote do projeto
package gradle;

// Importa ObjectMapper para JSON
import com.fasterxml.jackson.databind.ObjectMapper;
// Importa SerializationFeature para JSON
import com.fasterxml.jackson.databind.SerializationFeature;
// Importa JavaTimeModule para datas
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;


// Importa IOException para exceções
import java.io.IOException;
// Importa ArrayList para listas
import java.util.ArrayList;
// Importa List para listas
import java.util.List;

// Define a classe ImportExportUtil
public class ImportExportUtil {

    // Declara atributo objectMapper
    private static final ObjectMapper objectMapper = new ObjectMapper()
            // Registra módulo JavaTime
            .registerModule(new JavaTimeModule())
            // Configura serialização de datas
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            // Habilita tipagem padrão
            .enableDefaultTyping();

    // Define a classe TeamData
    public static class TeamData {
        // Declara atributo alliedTeam
        public List<Tanque> alliedTeam;
        // Declara atributo enemyTeam
        public List<Tanque> enemyTeam;

        // Define construtor vazio
        public TeamData() {}

        // Define construtor com parâmetros
        public TeamData(List<Tanque> alliedTeam, List<Tanque> enemyTeam) {
            // Atribui alliedTeam
            this.alliedTeam = alliedTeam;
            // Atribui enemyTeam
            this.enemyTeam = enemyTeam;
        }
    }

    // Define o método exportToJSON
    public static void exportToJSON(List<Tanque> alliedTeam, List<Tanque> enemyTeam, String filePath) throws IOException {
        // Cria TeamData
        TeamData data = new TeamData(alliedTeam, enemyTeam);
        // Escreve no arquivo
        objectMapper.writeValue(new java.io.File(filePath), data);
    }

    // Define o método importFromJSON
    public static TeamData importFromJSON(String filePath) throws IOException {
        // Lê do arquivo
        return objectMapper.readValue(new java.io.File(filePath), TeamData.class);
    }






}
