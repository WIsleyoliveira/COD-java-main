package gradle;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Modos {
    Scanner sc = new Scanner(System.in);
    Date dataHora;
    double duracao;
    int arena;
    LocalDateTime agora = LocalDateTime.now();
    DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    String formatada = agora.format(formato);
    ArrayList<Tanque> tanquesAliado;
    ArrayList<Tanque> tanqueInimigo;
    ArrayList<Partida> historicoPartidas = new ArrayList<>();

    public Modos(Date dataHora, double duracao, int arena, ArrayList<Tanque> tanquesAliado, ArrayList<Tanque> tanqueInimigo) {
        this.dataHora = dataHora;
        this.duracao = duracao;
        this.arena = arena;
        this.tanquesAliado = tanquesAliado;
        this.tanqueInimigo = tanqueInimigo;
    }

    void modoTreino() {
        if (tanquesAliado.isEmpty() || tanqueInimigo.isEmpty()) {
            System.out.println("Você deve criar tanques aliados e inimigos para continuar!");
            return;
        }

        System.out.println("Escolha um mapa: ");
        System.out.println("(1) Deserto");
        System.out.println("(2) Urbano");
        System.out.println("(3) Campo Aberto");
        arena = sc.nextInt();

        String nomeArena = switch (arena) {
            case 1 -> "Deserto";
            case 2 -> "Urbano";
            case 3 -> "Campo Aberto";
            default -> "Desconhecido";
        };

        System.out.println("Mapa selecionado: " + nomeArena);
        System.out.println("Horário inicial da partida: " + formatada);

        Tanque tanqueAliado = tanquesAliado.get(0);
        Tanque tanqueInimigoObj = tanqueInimigo.get(0);

        if (arena == 1) {
            tanqueAliado.setVelocidade((int)(tanqueAliado.getVelocidade() * 0.60));
            tanqueInimigoObj.setVelocidade((int)(tanqueInimigoObj.getVelocidade() * 0.60));
        } else if (arena == 2) {
            tanqueAliado.setBlindagem(tanqueAliado.getBlindagem() * 2);
            tanqueInimigoObj.setBlindagem(tanqueInimigoObj.getBlindagem() * 2);
        } else if (arena == 3) {
            tanqueAliado.setPoderDeFogo(tanqueAliado.getPoderDeFogo() * 2);
            tanqueInimigoObj.setPoderDeFogo(tanqueInimigoObj.getPoderDeFogo() * 2);
        }

        historicoPartidas.add(new Partida("Treino", nomeArena, LocalDateTime.now(), tanquesAliado, tanqueInimigo));
        System.out.println("Partida de treino agendada!");
    }

    void modoPvP() {
        if (tanquesAliado.isEmpty() || tanqueInimigo.isEmpty()) {
            System.out.println("Você deve criar tanques aliados e inimigos para continuar!");
            return;
        }

        System.out.println("Agendamento de Partida PvP");
        System.out.print("Data (dd/MM/yyyy): ");
        String dataStr = sc.next();
        System.out.print("Hora (HH:mm): ");
        String horaStr = sc.next();
        System.out.print("Duração (horas): ");
        double duracaoPvP = sc.nextDouble();

        System.out.println("Escolha um mapa: ");
        System.out.println("(1) Deserto");
        System.out.println("(2) Urbano");
        System.out.println("(3) Campo Aberto");
        int arenaPvP = sc.nextInt();

        String nomeArena = switch (arenaPvP) {
            case 1 -> "Deserto";
            case 2 -> "Urbano";
            case 3 -> "Campo Aberto";
            default -> "Desconhecido";
        };

        LocalDateTime dataHora = LocalDateTime.parse(dataStr + "T" + horaStr);
        historicoPartidas.add(new Partida("PvP", nomeArena, dataHora, tanquesAliado, tanqueInimigo));
        System.out.println("Partida PvP agendada!");
    }

    void modoTvT() {
        System.out.println("Agendamento de Partida Time vs Time");
        System.out.print("Quantos tanques por time? ");
        int tamanhoTime = sc.nextInt();

        System.out.print("Data (dd/MM/yyyy): ");
        String dataStr = sc.next();
        System.out.print("Hora (HH:mm): ");
        String horaStr = sc.next();
        System.out.print("Duração (horas): ");
        double duracaoTvT = sc.nextDouble();

        System.out.println("Escolha um mapa: ");
        System.out.println("(1) Deserto");
        System.out.println("(2) Urbano");
        System.out.println("(3) Campo Aberto");
        int arenaTvT = sc.nextInt();

        String nomeArena = switch (arenaTvT) {
            case 1 -> "Deserto";
            case 2 -> "Urbano";
            case 3 -> "Campo Aberto";
            default -> "Desconhecido";
        };

        LocalDateTime dataHora = LocalDateTime.parse(dataStr + "T" + horaStr);
        historicoPartidas.add(new Partida("TvT", nomeArena, dataHora, tanquesAliado, tanqueInimigo));
        System.out.println("Partida TvT agendada!");
    }

    public void gerarRankingPorModo(String modo) {
        List<Tanque> todos = new ArrayList<>();
        for (Partida p : historicoPartidas) {
            if (p.getTipo().equalsIgnoreCase(modo)) {
                todos.addAll(p.getTanquesAliado());
                todos.addAll(p.getTanquesInimigo());
            }
        }
        todos.sort((a, b) -> Integer.compare(b.calcularScore(), a.calcularScore()));
        System.out.println("\n=== Ranking " + modo + " ===");
        for (int i = 0; i < todos.size(); i++) {
            Tanque t = todos.get(i);
            System.out.printf("%dº - %s | Score: %d\n", i + 1, t.getCodinome(), t.calcularScore());
        }
    }

    public void taxaDeVitoriaPorPiloto() {
        Map<String, Integer> total = new HashMap<>();
        Map<String, Integer> vitorias = new HashMap<>();

        for (Partida p : historicoPartidas) {
            for (Tanque t : p.getTanquesAliado()) {
                String piloto = t.getTipoPiloto();
                total.put(piloto, total.getOrDefault(piloto, 0) + 1);
                if (t.calcularScore() > 500) {
                    vitorias.put(piloto, vitorias.getOrDefault(piloto, 0) + 1);
                }
            }
        }

        System.out.println("\n=== Taxa de Vitória por Piloto ===");
        for (String piloto : total.keySet()) {
            int vit = vitorias.getOrDefault(piloto, 0);
            int tot = total.get(piloto);
            double taxa = (double) vit / tot * 100;
            System.out.printf("%s: %.2f%% de vitória\n", piloto, taxa);
        }
    }

    public void mapaDeCalor() {
        Map<Integer, Integer> ocupacao = new HashMap<>();
        for (Partida p : historicoPartidas) {
            int hora = p.getDataHora().getHour();
            ocupacao.put(hora, ocupacao.getOrDefault(hora, 0) + 1);
        }
        System.out.println("\n=== Mapa de Calor ===");
        for (int h = 0; h < 24; h++) {
            System.out.printf("%02d:00 - %d partidas\n", h, ocupacao.getOrDefault(h, 0));
        }
    }

    public void topArmas() {
        Map<String, Integer> dano = new HashMap<>();
        Map<String, Integer> tiros = new HashMap<>();
        Map<String, Integer> acertos = new HashMap<>();

        for (Partida p : historicoPartidas) {
            for (Tanque t : p.getTanquesAliado()) {
                String arma = t.getArmaSelecionada();
                dano.put(arma, dano.getOrDefault(arma, 0) + t.getDanoCausado());
                tiros.put(arma, tiros.getOrDefault(arma, 0) + t.getTirosDisparados());
                acertos.put(arma, acertos.getOrDefault(arma, 0) + t.getTirosAcertados());
            }
        }

        System.out.println("\n=== Top Armas ===");
        for (String arma : dano.keySet()) {
            double precisao = tiros