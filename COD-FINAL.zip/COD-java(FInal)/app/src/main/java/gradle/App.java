package gradle;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.Random;

public class App {
    public String getGreeting() {
        return "Hello World!";
    }

    public static void main(String[] args) {
        System.out.println(new App().getGreeting());
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        ArrayList<Tanque> tanquesAliado = new ArrayList<>();
        ArrayList<Tanque> tanqueInimigo = new ArrayList<>();
        Modos modos = new Modos(null, 0, 0, tanquesAliado, tanqueInimigo);

        int opcao;
        while (true) {
            try {
                System.out.println("\n#===# Menu #===#");
                System.out.printf("Tanques Aliados: %d\n", tanquesAliado.size());
                System.out.printf("Tanques Inimigos: %d\n", tanqueInimigo.size());
                System.out.println("(1) Criar tanque");
                System.out.println("(2) Começar partida");
                System.out.println("(3) Ver relatório dos tanques");
                System.out.println("(4) Ranking global");
                System.out.println("(5) Taxa de vitória por classe");
                System.out.println("(6) Mapa de calor de horários");
                System.out.println("(7) Top armas por desempenho");
                System.out.println("(8) Disponibilidade da frota");
                System.out.println("(9) Sair");
                System.out.print("Escolha uma opção: ");
                opcao = sc.nextInt();

                switch (opcao) {
                    case 1:
                        sc.nextLine();
                        System.out.println("Você quer criar um tanque aliado ou inimigo?");
                        System.out.println("(1) Aliado");
                        System.out.println("(2) Inimigo");
                        int opAliado = sc.nextInt();

                        System.out.print("Digite o codinome: ");
                        sc.nextLine();
                        String codinome = sc.nextLine();

                        System.out.print("Digite a blindagem: ");
                        int blindagem = sc.nextInt();

                        System.out.print("Digite a velocidade: ");
                        int velocidade = sc.nextInt();

                        System.out.print("Digite o poder de fogo: ");
                        int poderDeFogo = sc.nextInt();

                        System.out.println("Escolha o tipo de tanque: \n(1) Leve \n(2) Médio \n(3) Pesado");
                        int opTanque = sc.nextInt();

                        System.out.println("Escolha a arma: \n(1) Metralhadora \n(2) Míssil \n(3) Canhão");
                        int opArma = sc.nextInt();

                        Date horaEntrada = new Date();
                        Tanque novoTanque = null;

                        if (opTanque == 1) {
                            novoTanque = new Leve(random.nextInt(999) + 100, codinome, blindagem, velocidade, poderDeFogo, horaEntrada);
                        } else if (opTanque == 2) {
                            novoTanque = new Medio(random.nextInt(999) + 100, codinome, blindagem, velocidade, poderDeFogo, horaEntrada);
                        } else if (opTanque == 3) {
                            novoTanque = new Pesado(random.nextInt(999) + 100, codinome, blindagem, velocidade, poderDeFogo, horaEntrada);
                        }

                        if (novoTanque != null) {
                            novoTanque.armasCaract("Metralhadora", "Missil", "Canhao", opArma);

                            // Valores zerados para iniciar sem estatísticas
                            novoTanque.setAbates(0);
                            novoTanque.setAssistencias(0);
                            novoTanque.setDanoCausado(0);
                            novoTanque.setDanoRecebido(0);
                            novoTanque.setTirosDisparados(0);
                            novoTanque.setTirosAcertados(0);
                            novoTanque.setObjetivosCapturaDefesa(0);
                            novoTanque.setTempoCombate(0);

                            if (opAliado == 1) {
                                tanquesAliado.add(novoTanque);
                                System.out.println("Tanque aliado criado com sucesso!");
                            } else {
                                tanqueInimigo.add(novoTanque);
                                System.out.println("Tanque inimigo criado com sucesso!");
                            }
                        }
                        break;

                    case 2:
                        System.out.println("Selecione um modo");
                        System.out.println("(1) Treino");
                        System.out.println("(2) PvP");
                        System.out.println("(3) TvT");
                        int opModo = sc.nextInt();

                        if (opModo == 1) modos.modoTreino();
                        else if (opModo == 2) modos.modoPvP();
                        else if (opModo == 3) modos.modoTvT();
                        break;

                    case 3:
                        System.out.println("\n=== Relatórios dos Tanques Aliados ===");
                        for (Tanque t : tanquesAliado) {
                            System.out.println(t.gerarRelatorioDetalhado());
                        }

                        System.out.println("\n=== Relatórios dos Tanques Inimigos ===");
                        for (Tanque t : tanqueInimigo) {
                            System.out.println(t.gerarRelatorioDetalhado());
                        }
                        break;

                    case 4: modos.gerarRanking(); break;
                    case 5: modos.taxaDeVitoriaPorClasse(); break;
                    case 6: modos.mapaDeCalorHorarios(); break;
                    case 7: modos.topArmasPorDesempenho(); break;
                    case 8: modos.disponibilidadeFrota(); break;

                    case 9:
                        System.out.println("Encerrando o programa...");
                        return;

                    default:
                        System.out.println("Opção inválida! Tente novamente.");
                        break;
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Entrada inválida! Por favor, digite um número válido.");
                sc.nextLine();
            } catch (java.util.NoSuchElementException e) {
                System.out.println("\nEncerrando o programa...");
                break;
            } catch (Exception e) {
                System.out.println("Erro inesperado: " + e.getMessage());
                sc.nextLine();
            }
        }
    }
}
