package gradle;

import java.time.Duration;
import java.util.Date;

public class Leve extends Tanque {
    private int danoBase;
    private double alcanceEficaz;
    private Duration recarga;

    public Leve(int id, String codinome, int blindagem, int velocidade, int poderDeFogo, Date horaEntradaArena) {
        super(id, codinome, blindagem, velocidade, poderDeFogo, horaEntradaArena);
    }

    public Leve() {
        super();
    }

    @Override
    public void Caracteristicas() {
        danoBase = 10;
        registrarEvento("Tanque leve inicializado com dano base 10");
    }

    @Override
    void armasCaract(String metralhadora, String missil, String canhao, int escolha) {
        Caracteristicas(); // garante que danoBase = 10

        switch (escolha) {
            case 1:
                danoBase *= 2;
                alcanceEficaz = 8;
                recarga = Duration.ofSeconds(2);
                registrarEvento("Equipado com Metralhadora (dano x2, alcance 8, recarga 2s)");
                break;
            case 2:
                danoBase *= 6;
                alcanceEficaz = 10;
                recarga = Duration.ofSeconds(8);
                registrarEvento("Equipado com Míssil (dano x6, alcance 10, recarga 8s)");
                break;
            case 3:
                danoBase *= 12;
                alcanceEficaz = 20;
                recarga = Duration.ofSeconds(14);
                registrarEvento("Equipado com Canhão (dano x12, alcance 20, recarga 14s)");
                break;
            default:
                danoBase = 0;
                alcanceEficaz = 0;
                recarga = Duration.ZERO;
                registrarEvento("Arma inválida selecionada");
        }
    }

    // Getters para relatório detalhado
    public int getDanoBase() {
        return danoBase;
    }

    public double getAlcanceEficaz() {
        return alcanceEficaz;
    }

    public Duration getRecarga() {
        return recarga;
    }
}

