package gradle;

import java.util.ArrayList;
import java.util.Date;

public abstract class Tanque {
    private int id;
    private String codinome;
    private int blindagem;
    private int velocidade;
    private int poderDeFogo;
    private Date horaEntradaArena;

    private int abates;
    private int assistencias;
    private int danoCausado;
    private int danoRecebido;
    private int tirosDisparados;
    private int tirosAcertados;
    private int objetivosCapturaDefesa;
    private long tempoCombate;

    private String tipoPiloto;
    private boolean emManutencao;
    private String armaSelecionada;

    private ArrayList<String> eventos = new ArrayList<>();

    public Tanque(int id, String codinome, int blindagem, int velocidade, int poderDeFogo, Date horaEntradaArena) {
        this.id = id;
        this.codinome = codinome;
        this.blindagem = blindagem;
        this.velocidade = velocidade;
        this.poderDeFogo = poderDeFogo;
        this.horaEntradaArena = horaEntradaArena;
    }

    public Tanque() {}

    abstract void armasCaract(String Metralhadora, String Missil, String Canhao, int escolha);
    public abstract void Caracteristicas();

    public int getId() { return id; }
    public String getCodinome() { return codinome; }
    public int getBlindagem() { return blindagem; }
    public void setBlindagem(int blindagem) { this.blindagem = blindagem; }
    public int getVelocidade() { return velocidade; }
    public void setVelocidade(int velocidade) { this.velocidade = velocidade; }
    public int getPoderDeFogo() { return poderDeFogo; }
    public void setPoderDeFogo(int poderDeFogo) { this.poderDeFogo = poderDeFogo; }
    public Date getHoraEntradaArena() { return horaEntradaArena; }

    public void setAbates(int abates) { this.abates = abates; }
    public void setAssistencias(int assistencias) { this.assistencias = assistencias; }
    public void setDanoCausado(int danoCausado) { this.danoCausado = danoCausado; }
    public void setDanoRecebido(int danoRecebido) { this.danoRecebido = danoRecebido; }
    public void setTirosDisparados(int tirosDisparados) { this.tirosDisparados = tirosDisparados; }
    public void setTirosAcertados(int tirosAcertados) { this.tirosAcertados = tirosAcertados; }
    public void setObjetivosCapturaDefesa(int objetivos) { this.objetivosCapturaDefesa = objetivos; }
    public void setTempoCombate(long tempoCombate) { this.tempoCombate = tempoCombate; }

    public int getAbates() { return abates; }
    public int getAssistencias() { return assistencias; }
    public int getDanoCausado() { return danoCausado; }
    public int getDanoRecebido() { return danoRecebido; }
    public int getTirosDisparados() { return tirosDisparados; }
    public int getTirosAcertados() { return tirosAcertados; }
    public int getObjetivosCapturaDefesa() { return objetivosCapturaDefesa; }
    public long getTempoCombate() { return tempoCombate; }

    public void setTipoPiloto(String tipo) { this.tipoPiloto = tipo; }
    public String getTipoPiloto() { return tipoPiloto; }

    public void setEmManutencao(boolean status) { this.emManutencao = status; }
    public boolean isEmManutencao() { return emManutencao; }

    public void setArmaSelecionada(String arma) { this.armaSelecionada = arma; }
    public String getArmaSelecionada() { return armaSelecionada; }

    public void registrarEvento(String evento) {
        eventos.add(evento);
    }

    public ArrayList<String> getEventos() {
        return eventos;
    }

    public int calcularScore() {
        int score = abates * 100 + assistencias * 40 + objetivosCapturaDefesa * 120;
        if (tirosDisparados > 0) {
            double eficiencia = (double) tirosAcertados / tirosDisparados;
            score += (int)(eficiencia * 100);
        }
        return score;
    }

    public String gerarRelatorioDetalhado() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n--- Relatório do Tanque ---\n");
        sb.append("Codinome: ").append(codinome).append("\n");
        sb.append("Classe: ").append(this.getClass().getSimpleName()).append("\n");
        sb.append("Piloto: ").append(tipoPiloto != null ? tipoPiloto : "Não definido").append("\n");
        sb.append("Em manutenção: ").append(emManutencao ? "Sim" : "Não").append("\n");
        sb.append("Arma: ").append(armaSelecionada != null ? armaSelecionada : "Não definida").append("\n");
        sb.append("Score: ").append(calcularScore()).append("\n");
        sb.append("Abates: ").append(abates).append(" | Assistências: ").append(assistencias).append("\n");
        sb.append("Dano causado: ").append(danoCausado).append(" | Dano recebido: ").append(danoRecebido).append("\n");
        sb.append("Tiros: ").append(tirosDisparados).append(" | Acertos: ").append(tirosAcertados).append("\n");
        sb.append("Precisão: ").append(tirosDisparados > 0 ? String.format("%.2f%%", (double) tirosAcertados / tirosDisparados * 100) : "0%").append("\n");
        sb.append("Objetivos: ").append(objetivosCapturaDefesa).append("\n");
        sb.append("Tempo em combate: ").append(tempoCombate / 1000).append(" segundos\n");
        sb.append("Eventos:\n");
        for (String evento : eventos) {
            sb.append(" - ").append(evento).append("\n");
        }
        return sb.toString();
    }
}

