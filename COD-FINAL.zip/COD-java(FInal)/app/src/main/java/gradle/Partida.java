package gradle;

import java.time.LocalDateTime;
import java.util.List;

public class Partida {
    private String tipo; // "Treino", "PvP", "TvT"
    private String mapa;
    private LocalDateTime dataHora;
    private List<Tanque> tanquesAliado;
    private List<Tanque> tanquesInimigo;

    public Partida(String tipo, String mapa, LocalDateTime dataHora, List<Tanque> tanquesAliado, List<Tanque> tanquesInimigo) {
        this.tipo = tipo;
        this.mapa = mapa;
        this.dataHora = dataHora;
        this.tanquesAliado = tanquesAliado;
        this.tanquesInimigo = tanquesInimigo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getMapa() {
        return mapa;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public List<Tanque> getTanquesAliado() {
        return tanquesAliado;
    }

    public List<Tanque> getTanquesInimigo() {
        return tanquesInimigo;
    }

    @Override
    public String toString() {
        return "Partida [" + tipo + "] - Mapa: " + mapa + " - Data: " + dataHora.toString();
    }
}


