package gradle;

import java.time.Duration;
import java.util.Date;

public class Pesado extends Tanque {
    private int danoBase;
    private double alcanceEficaz;
    private Duration recarga;

    public Pesado(int id, String codinome, int blindagem, int velocidade, int poderDeFogo, Date horaEntradaArena) {
        super(id, codinome, blindagem, velocidade, poderDeFogo, horaEntradaArena);
    }

    public Pesado() {
        super();
    }

    @Override
    void armasCaract(String metralhadora, String missil, String canhao, int escolha) {
        Caracteristicas(); // Inicializa danoBase

        switch (escolha) {
            case 1:
                danoBase *= 3;
                alcanceEficaz = 6;
                recarga = Duration.ofSeconds(4);
                registrarEvento("Equipado com Metralhadora (dano x3, alcance 6, recarga 4s)");
                break;
            case 2:
                danoBase *= 10;
                alcanceEficaz = 8;
                recarga = Duration.ofSeconds(12);
                registrarEvento("Equipado com Míssil (dano x10, alcance 8, recarga 12s)");
                break;
            case 3:
                danoBase *= 15;
                alcanceEficaz = 25;
                recarga = Duration.ofSeconds(18);
                registrarEvento("Equipado com Canhão (dano x15, alcance 25, recarga 18s)");
                break;
            default:
                danoBase = 0;
                alcanceEficaz = 0;
                recarga = Duration.ZERO;
                registrarEvento("Arma inválida selecionada");
        }
    }

    @Override
    public void Caracteristicas() {
        danoBase = 20;
        registrarEvento("Tanque pesado inicializado com dano base 20");
    }

    // Getters para relatório detalhado
    public int getDanoBase() {
        return danoBase;
    }

    public double getAlcanceEficaz() {
        return alcanceEficaz;
    }

    public Duration getRecarga() {
        return recarga;
    }
}
