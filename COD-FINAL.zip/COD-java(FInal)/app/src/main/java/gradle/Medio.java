package gradle;

import java.time.Duration;
import java.util.Date;

public class Medio extends Tanque {
    private int danoBase;
    private double alcanceEficaz;
    private Duration recarga;

    public Medio(int id, String codinome, int blindagem, int velocidade, int poderDeFogo, Date horaEntradaArena) {
        super(id, codinome, blindagem, velocidade, poderDeFogo, horaEntradaArena);
    }

    public Medio() {
        super();
    }

    @Override
    public void Caracteristicas() {
        danoBase = 15;
        registrarEvento("Tanque médio inicializado com dano base 15");
    }

    @Override
    void armasCaract(String metralhadora, String missil, String canhao, int escolha) {
        Caracteristicas(); // garante que danoBase = 15

        switch (escolha) {
            case 1:
                danoBase *= 4;
                alcanceEficaz = 5;
                recarga = Duration.ofSeconds(5);
                registrarEvento("Equipado com Metralhadora (dano x4, alcance 5, recarga 5s)");
                break;
            case 2:
                danoBase *= 8;
                alcanceEficaz = 6;
                recarga = Duration.ofSeconds(10);
                registrarEvento("Equipado com Míssil (dano x8, alcance 6, recarga 10s)");
                break;
            case 3:
                danoBase *= 12;
                alcanceEficaz = 20;
                recarga = Duration.ofSeconds(14);
                registrarEvento("Equipado com Canhão (dano x12, alcance 20, recarga 14s)");
                break;
            default:
                danoBase = 0;
                alcanceEficaz = 0;
                recarga = Duration.ZERO;
                registrarEvento("Arma inválida selecionada");
        }
    }

    // Getters para relatório detalhado
    public int getDanoBase() {
        return danoBase;
    }

    public double getAlcanceEficaz() {
        return alcanceEficaz;
    }

    public Duration getRecarga() {
        return recarga;
    }
}

